function formatNumber(num) {
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
} 

function getNowDate() {
    var date = new Date()
    var year = date.getFullYear();
    var month = date.getMonth() + 1;//month start with 0
    var day = date.getDate();

    var today = year + "-" + month + "-" + day;
    return today;
}

function getNowTime() {
    var date = new Date()
    var hour = date.getHours();
    var minute = date.getMinutes();//month start with 0
    var second = date.getSeconds();

    var now = hour + ":" + minute + ":" + second;
    return now;
}